ENV['RACK_ENV'] ||= "development"

require File.expand_path('../application', __FILE__)